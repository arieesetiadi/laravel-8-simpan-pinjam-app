$(function () {
    // Init global Select2
    $('.select-2').select2();
});